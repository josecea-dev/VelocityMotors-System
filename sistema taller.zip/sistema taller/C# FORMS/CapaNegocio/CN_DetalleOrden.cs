﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using CapaDatos;
namespace CapaNegocio
{
    public class CN_DetalleOrden
    {
        public static DataTable ExtraerGanacias()
        {
            return new CD_DetalleOrden().ExtraerGanancias();
        }
    }
}
