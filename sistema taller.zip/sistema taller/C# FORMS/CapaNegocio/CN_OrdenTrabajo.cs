﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using CapaDatos;
namespace CapaNegocio
{
    public class CN_OrdenTrabajo
    {
        public static DataTable TotalOrdenes()
        {
            return new CD_OrdenTrabajo().TotalOrdenes();
        }
        public static int MetaOrdenes(int PedidosCompletados)
        {
            int meta_actual = 27; //esto representa la meta de 27 ordenes, mi idea es que esta meta sea modifcable, representando una meta para los empleados/admins

            if (PedidosCompletados <= 0)
                return 0;

            int porcentaje = (PedidosCompletados * 100) / meta_actual; 

            if (porcentaje >= 100)
                return 100;

            return porcentaje;

        }
        public static DataTable mostrar()
        {
            return new CD_OrdenTrabajo().Mostrar();
        }
        public static DataTable buscar(string buscar)
        {
            CD_OrdenTrabajo OBJ = new CD_OrdenTrabajo();
            OBJ.Buscar = buscar;
            return CD_OrdenTrabajo.buscar(OBJ);
        }
        public static DataTable mostrarCards()
        {
            return new CD_OrdenTrabajo().mostrar_cards();
        }
        public static string InsertarCards(string estado, string observaciones, int idVehiculo, int idEmpleado, int cantidad, decimal precio, int idServicio)
        {
            CD_OrdenTrabajo OBJ = new CD_OrdenTrabajo();
            OBJ.Estado = estado;
            OBJ.Observaciones = observaciones;
            OBJ.IdVehiculo = idVehiculo;
            OBJ.IdEmpleado = idEmpleado;
            OBJ.Cantidad = cantidad;
            OBJ.Precio = precio;
            OBJ.IdServicio = idServicio;

            return CD_OrdenTrabajo.InsertarCards(OBJ);
        }
    }
}
