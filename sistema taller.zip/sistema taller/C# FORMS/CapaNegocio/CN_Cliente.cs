﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using CapaDatos;
namespace CapaNegocio
{
    public class CN_Cliente
    {
        public static DataTable mostrar()
        {
            return new CD_Cliente().mostrar();
        }
        public static DataTable buscar(string nombre)
        {
            CD_Cliente OBJ = new CD_Cliente();
            OBJ.Buscar = nombre;
            return CD_Cliente.buscar(OBJ);
        }
        public static string Insertar(string cedula, string nombres, string apellidos, string correo, string telefono)
        {
            CD_Cliente OBJ = new CD_Cliente();
            OBJ.Cedula = cedula;
            OBJ.Nombre = nombres;
            OBJ.Apellido = apellidos;
            OBJ.Correo = correo;
            OBJ.Telefono = telefono;
            return CD_Cliente.insertar(OBJ);
        }
        public static string Editar(int id, string cedula, string nombres, string apellidos, string correo, string telefono)
        {
            CD_Cliente OBJ = new CD_Cliente();
            OBJ.Id = id;
            OBJ.Cedula = cedula;
            OBJ.Nombre = nombres;
            OBJ.Apellido = apellidos;
            OBJ.Correo = correo;
            OBJ.Telefono = telefono;
            return CD_Cliente.Editar(OBJ);
        }
        public static string Eliminar(int id)
        {
            CD_Cliente OBJ = new CD_Cliente();
            OBJ.Id = id;
            return CD_Cliente.Eliminar(OBJ);
        }
    }
}
