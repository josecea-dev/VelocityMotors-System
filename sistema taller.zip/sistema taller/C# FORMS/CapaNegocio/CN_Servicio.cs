﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using CapaDatos;

namespace CapaNegocio
{
    public class CN_Servicio
    {
        public static DataTable Mostrar()
        {
            return new CD_Servicio().mostrar();
        }
        public static string Insertar(string nombre, string descripcion, decimal precio)
        {
            CD_Servicio OBJ = new CD_Servicio();
            OBJ.Nombre = nombre;
            OBJ.Descripcion = descripcion;
            OBJ.Precio = precio;
            return CD_Servicio.insertar(OBJ);
        }
        public static DataTable buscar(string nombre)
        {
            CD_Servicio OBJ = new CD_Servicio();
            OBJ.Buscar = nombre;
            return CD_Servicio.buscar(OBJ);
        }
        public static string Editar(int id, string nombre, string descripcion, decimal precio)
        {
            CD_Servicio OBJ = new CD_Servicio();
            OBJ.Id = id;
            OBJ.Nombre = nombre;
            OBJ.Descripcion = descripcion;
            OBJ.Precio = precio;
            return CD_Servicio.Editar(OBJ);
        }
        public static string Eliminar(int id)
        {
            CD_Servicio OBJ = new CD_Servicio();
            OBJ.Id = id;
            return CD_Servicio.Eliminar(OBJ);
        }
    }
}
