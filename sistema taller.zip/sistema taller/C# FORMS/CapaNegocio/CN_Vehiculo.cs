﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using CapaDatos;

namespace CapaNegocio
{
    public class CN_Vehiculo
    {
        public static DataTable mostrar()
        {
            return new CD_Vehiculo().mostrar();
        }

        public static DataTable buscar(string marca)
        {
            CD_Vehiculo OBJ = new CD_Vehiculo();
            OBJ.Buscar = marca;
            return CD_Vehiculo.buscar(OBJ);
        }

        public static string Insertar(string placa, string marca, string modelo, int anio, int idCliente)
        {
            CD_Vehiculo OBJ = new CD_Vehiculo();
            OBJ.Placa = placa;
            OBJ.Marca = marca;
            OBJ.Modelo = modelo;
            OBJ.Anio = anio;
            OBJ.IdCliente = idCliente;
            return CD_Vehiculo.insertar(OBJ);
        }

        public static string Editar(int idVehiculo, string placa, string marca, string modelo, int anio, int idCliente)
        {
            CD_Vehiculo OBJ = new CD_Vehiculo();
            OBJ.IdVehiculo = idVehiculo;
            OBJ.Placa = placa;
            OBJ.Marca = marca;
            OBJ.Modelo = modelo;
            OBJ.Anio = anio;
            OBJ.IdCliente = idCliente;
            return CD_Vehiculo.Editar(OBJ);
        }

        public static string Eliminar(int idVehiculo)
        {
            CD_Vehiculo OBJ = new CD_Vehiculo();
            OBJ.IdVehiculo = idVehiculo;
            return CD_Vehiculo.Eliminar(OBJ);
        }
    }
}
