﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using CapaDatos;
namespace CapaNegocio
{
    public class CN_Empleado
    {
        public static DataTable mostrar()
        {
            return new CD_Empleado().mostrar();
        }
        public static string Login(string correo, string password)
        {
            CD_Empleado OBJ = new CD_Empleado();    
            OBJ.Correo = correo;
            OBJ.Password = password;
            return CD_Empleado.Login(OBJ);
        }
        public static DataTable extraer_rol(string correo, string password)
        {
            CD_Empleado OBJ = new CD_Empleado();
            OBJ.Correo = correo;
            OBJ.Password = password;
            return CD_Empleado.Extraer_rol(OBJ);
        }
        public static DataTable buscar(string nombre)
        {
            CD_Empleado OBJ = new CD_Empleado();
            OBJ.Buscar = nombre;
            return CD_Empleado.buscar(OBJ);
        }
        public static string Insertar(string cedula, string nombres, string apellidos, string correo, string telefono, string rol, string password)
        {
            CD_Empleado OBJ = new CD_Empleado();
            OBJ.Cedula = cedula;
            OBJ.Nombre = nombres;
            OBJ.Apellido = apellidos;
            OBJ.Correo = correo;
            OBJ.Telefono = telefono;
            OBJ.Rol = rol;
            OBJ.Password = password;
            return CD_Empleado.Insertar(OBJ);
        }
        public static string Editar(int id, string cedula, string nombres, string apellidos, string correo, string telefono, string rol, string password)
        {
            CD_Empleado OBJ = new CD_Empleado();
            OBJ.Id = id;
            OBJ.Cedula = cedula;
            OBJ.Nombre = nombres;
            OBJ.Apellido = apellidos;
            OBJ.Correo = correo;
            OBJ.Telefono = telefono;
            OBJ.Rol = rol;
            OBJ.Password = password;
            return CD_Empleado.Editar(OBJ);
        }
        public static string Eliminar(int id)
        {
            CD_Empleado OBJ = new CD_Empleado();
            OBJ.Id = id;
            return CD_Empleado.Eliminar(OBJ);
        }
    }
}
