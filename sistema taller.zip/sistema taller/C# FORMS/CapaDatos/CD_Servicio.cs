﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Documents;
using System.Windows;
namespace CapaDatos
{
    public class CD_Servicio
    {
        private int _id;
        private string _nombre;
        private string _descripcion;
        private decimal _precio;
        private string _buscar;

        public int Id { get => _id; set => _id = value; }
        public string Nombre { get => _nombre; set => _nombre = value; }
        public string Descripcion { get => _descripcion; set => _descripcion = value; }
        public decimal Precio { get => _precio; set => _precio = value; }
        public string Buscar { get => _buscar; set => _buscar = value; }

        public CD_Servicio()
        {

        }
        public CD_Servicio(int id, string nombre, string descripcion, decimal precio, string buscar)
        {
            this.Id = id;
            this.Nombre = nombre;
            this.Descripcion = descripcion;
            this.Precio = precio;
            this.Buscar = buscar;
        }
        public DataTable mostrar()
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            DataTable table = new DataTable("Servicio");

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_Mostrar";
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter dta = new SqlDataAdapter(cmd);
                dta.Fill(table);
            }
            catch 
            {
                table = null;
            }
            return table;
        }
        public static string insertar(CD_Servicio OBJ)
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            string respuesta = "";

            try
            {
                sqlcon.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_InsertarServicio";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@nombre", OBJ.Nombre);
                cmd.Parameters.AddWithValue("@descripcion", OBJ.Descripcion);
                cmd.Parameters.AddWithValue("@precio", OBJ.Precio);

                respuesta = cmd.ExecuteNonQuery() == 1 ? "Ok" : "No se pudo insertar los valores";
            }
            catch (Exception e) 
            {
                MessageBox.Show(e.Message + e.StackTrace);
            }
            return respuesta;
        }
        public static string Editar(CD_Servicio OBJ)
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            string respuesta = "";

            try
            {
                sqlcon.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_EditarServicio";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@id", OBJ.Id);
                cmd.Parameters.AddWithValue("@nombre", OBJ.Nombre);
                cmd.Parameters.AddWithValue("@descripcion", OBJ.Descripcion);
                cmd.Parameters.AddWithValue("@precio", OBJ.Precio);

                respuesta = cmd.ExecuteNonQuery() == 1 ? "Ok" : "No se pudo editar los valores";
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message + e.StackTrace);
            }
            return respuesta;
        }
        public static DataTable buscar(CD_Servicio OBJ )
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            DataTable table = new DataTable("Servicio");

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_BuscarServicio";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@nombre", OBJ.Buscar);

                SqlDataAdapter dta = new SqlDataAdapter(cmd);
                dta.Fill(table);
            }
            catch
            {
                table = null;
            }
            return table;
        }
        public static string Eliminar(CD_Servicio OBJ)
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            string respuesta = "";

            try
            {
                sqlcon.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_EliminarServicio";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@id", OBJ.Id);

                respuesta = cmd.ExecuteNonQuery() == 1 ? "Ok" : "No se pudo eliminar los valores";
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message + e.StackTrace);
            }
            return respuesta;
        }
    }
}
