﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Navigation;
using System.Windows;

namespace CapaDatos
{
    public class CD_Cliente
    {
        private int _id;
        private string _cedula;
        private string _nombre;
        private string _apellido;
        private string _correo;
        private string _telefono;
        private string _buscar;

        public int Id { get => _id; set => _id = value; }
        public string Cedula { get => _cedula; set => _cedula = value; }
        public string Nombre { get => _nombre; set => _nombre = value; }
        public string Apellido { get => _apellido; set => _apellido = value; }
        public string Correo { get => _correo; set => _correo = value; }
        public string Telefono { get => _telefono; set => _telefono = value; }
        public string Buscar { get => _buscar; set => _buscar = value; }

        public CD_Cliente()
        {

        }
        public CD_Cliente(int id, string cedula, string nombre, string apellido, string correo, string telefono, string buscar)
        {
            this.Id = id;
            this.Cedula = cedula;
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Correo = correo;
            this.Telefono = telefono;
            this.Buscar = buscar;
        }
        public DataTable mostrar()
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            DataTable tabla = new DataTable("Cliente");

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_MostrarCliente";
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter dta = new SqlDataAdapter(cmd);
                dta.Fill(tabla);
            }
            catch (Exception ex)
            {
                tabla = null;
            }
            return tabla;
        }
        public static DataTable buscar(CD_Cliente OBJ)
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            DataTable tabla = new DataTable("Cliente");

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_BuscarCliente";
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter parNombre = new SqlParameter();
                parNombre.ParameterName = "@nombre";
                parNombre.SqlDbType = SqlDbType.NVarChar;
                parNombre.Size = 50;
                parNombre.Value = OBJ.Buscar;
                cmd.Parameters.Add(parNombre);


                SqlDataAdapter dta = new SqlDataAdapter(cmd);
                dta.Fill(tabla);
            }
            catch (Exception ex)
            {
                tabla = null;
            }
            return tabla;
        }
        public static string insertar(CD_Cliente OBJ)
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            string respuesta = "";

            try
            {
                sqlcon.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_InsertarCliente";
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter parCedula = new SqlParameter();
                parCedula.ParameterName = "@cedula";
                parCedula.SqlDbType = SqlDbType.NVarChar;
                parCedula.Size = 20;
                parCedula.Value = OBJ.Cedula;
                cmd.Parameters.Add(parCedula);

                SqlParameter parNombres = new SqlParameter();
                parNombres.ParameterName = "@nombres";
                parNombres.SqlDbType = SqlDbType.NVarChar;
                parNombres.Size = 50;
                parNombres.Value = OBJ.Nombre;
                cmd.Parameters.Add(parNombres);

                SqlParameter parApellido = new SqlParameter();
                parApellido.ParameterName = "@apellidos";
                parApellido.SqlDbType = SqlDbType.NVarChar;
                parApellido.Size = 50;
                parApellido.Value = OBJ.Apellido;
                cmd.Parameters.Add(parApellido);

                SqlParameter parCorreo = new SqlParameter();
                parCorreo.ParameterName = "@correo";
                parCorreo.SqlDbType = SqlDbType.NVarChar;
                parCorreo.Size = 100;
                parCorreo.Value = OBJ.Correo;
                cmd.Parameters.Add(parCorreo);

                SqlParameter parTelefono = new SqlParameter();
                parTelefono.ParameterName = "@telefono";
                parTelefono.SqlDbType = SqlDbType.NVarChar;
                parTelefono.Size = 20;
                parTelefono.Value = OBJ.Telefono;
                cmd.Parameters.Add(parTelefono);

                respuesta = cmd.ExecuteNonQuery() == 1 ? "Ok" : "No se insertaron los valores";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (sqlcon.State == ConnectionState.Open)
                    sqlcon.Close();
            }
            return respuesta;
        }
        public static string Editar(CD_Cliente OBJ)
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            string respuesta = "";

            try
            {
                sqlcon.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_EditarCliente";
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter parId = new SqlParameter();
                parId.ParameterName = "@id";
                parId.SqlValue = SqlDbType.Int;
                parId.Value = OBJ.Id;
                cmd.Parameters.Add(parId);

                SqlParameter parCedula = new SqlParameter();
                parCedula.ParameterName = "@cedula";
                parCedula.SqlDbType = SqlDbType.NVarChar;
                parCedula.Size = 20;
                parCedula.Value = OBJ.Cedula;
                cmd.Parameters.Add(parCedula);

                SqlParameter parNombres = new SqlParameter();
                parNombres.ParameterName = "@nombres";
                parNombres.SqlDbType = SqlDbType.NVarChar;
                parNombres.Size = 50;
                parNombres.Value = OBJ.Nombre;
                cmd.Parameters.Add(parNombres);

                SqlParameter parApellido = new SqlParameter();
                parApellido.ParameterName = "@apellidos";
                parApellido.SqlDbType = SqlDbType.NVarChar;
                parApellido.Size = 50;
                parApellido.Value = OBJ.Apellido;
                cmd.Parameters.Add(parApellido);

                SqlParameter parCorreo = new SqlParameter();
                parCorreo.ParameterName = "@correo";
                parCorreo.SqlDbType = SqlDbType.NVarChar;
                parCorreo.Size = 100;
                parCorreo.Value = OBJ.Correo;
                cmd.Parameters.Add(parCorreo);

                SqlParameter parTelefono = new SqlParameter();
                parTelefono.ParameterName = "@telefono";
                parTelefono.SqlDbType = SqlDbType.NVarChar;
                parTelefono.Size = 20;
                parTelefono.Value = OBJ.Telefono;
                cmd.Parameters.Add(parTelefono);

                respuesta = cmd.ExecuteNonQuery() == 1 ? "Ok" : "No se editaron los valores";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (sqlcon.State == ConnectionState.Open)
                    sqlcon.Close();
            }
            return respuesta;
        }
        public static string Eliminar(CD_Cliente OBJ)
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            string respuesta = "";

            try
            {
                sqlcon.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_BorrarCliente";
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter parId = new SqlParameter();
                parId.ParameterName = "@id";
                parId.SqlValue = SqlDbType.Int;
                parId.Value = OBJ.Id;
                cmd.Parameters.Add(parId);


                respuesta = cmd.ExecuteNonQuery() == 1 ? "Ok" : "No se eliminaron los valores";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (sqlcon.State == ConnectionState.Open)
                    sqlcon.Close();
            }
            return respuesta;
        }
    }
}
