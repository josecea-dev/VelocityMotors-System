﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class cd_conexion
    {
        public static string cn = "Data Source = Cea; Initial Catalog = VelocityMotors_BD; Integrated Security = true;";
    }
}
