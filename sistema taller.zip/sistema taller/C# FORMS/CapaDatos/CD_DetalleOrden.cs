﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace CapaDatos
{
    public class CD_DetalleOrden
    {
        public  DataTable ExtraerGanancias()
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            DataTable table = new DataTable("DetalleOrden");

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_ExtraerGanancias";
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter dta = new SqlDataAdapter(cmd);
                dta.Fill(table);
            }
            catch (Exception ex)
            {
                table = null;
            }
            return table;
        }
    }
}
