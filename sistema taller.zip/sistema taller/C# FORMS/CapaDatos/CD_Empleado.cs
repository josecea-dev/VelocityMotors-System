﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
namespace CapaDatos
{
    public class CD_Empleado
    {
        private int _id;
        private string _cedula;
        private string _nombre;
        private string _apellido;
        private string _correo;
        private string _telefono;
        private string _password;
        private string _rol;
        private string _buscar;

        public int Id { get => _id; set => _id = value; }
        public string Cedula { get => _cedula; set => _cedula = value; }
        public string Nombre { get => _nombre; set => _nombre = value; }
        public string Apellido { get => _apellido; set => _apellido = value; }
        public string Correo { get => _correo; set => _correo = value; }
        public string Telefono { get => _telefono; set => _telefono = value; }
        public string Password { get => _password; set => _password = value; }
        public string Buscar { get => _buscar; set => _buscar = value; }
        public string Rol { get => _rol; set => _rol = value; }

        public CD_Empleado()
        {

        }
        public CD_Empleado(int id, string cedula, string nombre, string apellido, string correo, string telefono, string password, string buscar)
        {
            this.Id = id;
            this.Cedula = cedula;
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Correo = correo;
            this.Telefono = telefono;
            this.Password = password;
            this.Buscar = buscar;
        }
        public DataTable mostrar()
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            DataTable table = new DataTable("Empleado");

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_MostarEmpleado";
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter dta = new SqlDataAdapter(cmd);
                dta.Fill(table);
            }
            catch (Exception ex)
            {
                table = null;
            }
            return table;
        }
        public static string Login(CD_Empleado OBJ)
        {
            string respuesta = "";
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);

            try
            {
                sqlcon.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_Login";
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter parCorreo = new SqlParameter();
                parCorreo.ParameterName = "@correo";
                parCorreo.SqlDbType = SqlDbType.NVarChar;
                parCorreo.Size = 100;
                parCorreo.Value = OBJ.Correo;
                cmd.Parameters.Add(parCorreo);

                SqlParameter parPassword = new SqlParameter();
                parPassword.ParameterName = "@password";
                parPassword.SqlDbType = SqlDbType.NVarChar;
                parPassword.Size = 20;
                parPassword.Value = OBJ.Password;
                cmd.Parameters.Add(parPassword);

                SqlDataReader sql_read = cmd.ExecuteReader();

                if (sql_read.Read())
                    respuesta = "Ok";
                else
                    respuesta = "Usuarios o contraseña invalido";

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (sqlcon.State == ConnectionState.Open)
                    sqlcon.Close();
            }
            return respuesta;
        }
        public static DataTable Extraer_rol(CD_Empleado OBJ)
        {
            DataTable table = new DataTable("Empleado");
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_ExtrarRol";
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter parCorreo = new SqlParameter();
                parCorreo.ParameterName = "@correo";
                parCorreo.SqlDbType = SqlDbType.NVarChar;
                parCorreo.Size = 100;
                parCorreo.Value = OBJ.Correo;
                cmd.Parameters.Add(parCorreo);

                SqlParameter parPassword = new SqlParameter();
                parPassword.ParameterName = "@password";
                parPassword.SqlDbType = SqlDbType.NVarChar;
                parPassword.Size = 20;
                parPassword.Value = OBJ.Password;
                cmd.Parameters.Add(parPassword);

                SqlDataAdapter dta = new SqlDataAdapter(cmd);
                dta.Fill(table);
            }
            catch (Exception ex)
            {
                table = null;
            }
            return table;
        }
        public static DataTable buscar(CD_Empleado OBJ)
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            DataTable table = new DataTable("Empleado");

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_BuscarEmpleado";
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter parNombre = new SqlParameter();
                parNombre.ParameterName = "@nombres";
                parNombre.SqlDbType = SqlDbType.NVarChar;
                parNombre.Size = 50;
                parNombre.Value = OBJ.Buscar;
                cmd.Parameters.Add(parNombre);

                SqlDataAdapter dta = new SqlDataAdapter(cmd);
                dta.Fill(table);
            }
            catch (Exception ex) 
            {
                table = null;
            }
            return table;
        }
        public static string Insertar(CD_Empleado OBJ)
        {
            string respuesta = "";
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);

            try
            {
                sqlcon.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_InsertarEmpleado";
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter parCedula = new SqlParameter();
                parCedula.ParameterName = "@cedula";
                parCedula.SqlDbType = SqlDbType.NVarChar;
                parCedula.Size = 20;
                parCedula.Value = OBJ.Cedula;
                cmd.Parameters.Add(parCedula);

                SqlParameter parNombre = new SqlParameter();
                parNombre.ParameterName = "@nombres";
                parNombre.SqlDbType = SqlDbType.NVarChar;
                parNombre.Size = 50;
                parNombre.Value = OBJ.Nombre;
                cmd.Parameters.Add(parNombre);

                SqlParameter parApellido = new SqlParameter();
                parApellido.ParameterName = "@apellidos";
                parApellido.SqlDbType = SqlDbType.NVarChar;
                parApellido.Size = 50;
                parApellido.Value = OBJ.Apellido;
                cmd.Parameters.Add(parApellido);

                SqlParameter parCorreo = new SqlParameter();
                parCorreo.ParameterName = "@correo";
                parCorreo.SqlDbType = SqlDbType.NVarChar;
                parCorreo.Size = 100;
                parCorreo.Value = OBJ.Correo;
                cmd.Parameters.Add(parCorreo);

                SqlParameter parTelefono = new SqlParameter();
                parTelefono.ParameterName = "@telefono";
                parTelefono.SqlDbType = SqlDbType.NVarChar;
                parTelefono.Size = 20;
                parTelefono.Value = OBJ.Telefono;
                cmd.Parameters.Add(parTelefono);

                SqlParameter parRol = new SqlParameter();
                parRol.ParameterName = "@rol";
                parRol.SqlDbType = SqlDbType.NVarChar;
                parRol.Size = 50;
                parRol.Value = OBJ.Rol;
                cmd.Parameters.Add(parRol);

                SqlParameter parPassword = new SqlParameter();
                parPassword.ParameterName = "@password";
                parPassword.SqlDbType = SqlDbType.NVarChar;
                parPassword.Size = 20;
                parPassword.Value = OBJ.Password;
                cmd.Parameters.Add(parPassword);

                respuesta = cmd.ExecuteNonQuery() == 1 ? "Ok" : "No se pudo ingresar valores";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (sqlcon.State == ConnectionState.Open)
                    sqlcon.Close();
            }
            return respuesta;
        }
        public static string Editar(CD_Empleado OBJ)
        {
            string respuesta = "";
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);

            try
            {
                sqlcon.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_EditarEmpleado";
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter parId = new SqlParameter();
                parId.ParameterName = "@id";
                parId.SqlDbType = SqlDbType.Int;
                parId.Value = OBJ.Id;
                cmd.Parameters.Add(parId);

                SqlParameter parCedula = new SqlParameter();
                parCedula.ParameterName = "@cedula";
                parCedula.SqlDbType = SqlDbType.NVarChar;
                parCedula.Size = 20;
                parCedula.Value = OBJ.Cedula;
                cmd.Parameters.Add(parCedula);

                SqlParameter parNombre = new SqlParameter();
                parNombre.ParameterName = "@nombres";
                parNombre.SqlDbType = SqlDbType.NVarChar;
                parNombre.Size = 50;
                parNombre.Value = OBJ.Nombre;
                cmd.Parameters.Add(parNombre);

                SqlParameter parApellido = new SqlParameter();
                parApellido.ParameterName = "@apellidos";
                parApellido.SqlDbType = SqlDbType.NVarChar;
                parApellido.Size = 50;
                parApellido.Value = OBJ.Apellido;
                cmd.Parameters.Add(parApellido);

                SqlParameter parCorreo = new SqlParameter();
                parCorreo.ParameterName = "@correo";
                parCorreo.SqlDbType = SqlDbType.NVarChar;
                parCorreo.Size = 100;
                parCorreo.Value = OBJ.Correo;
                cmd.Parameters.Add(parCorreo);

                SqlParameter parTelefono = new SqlParameter();
                parTelefono.ParameterName = "@telefono";
                parTelefono.SqlDbType = SqlDbType.NVarChar;
                parTelefono.Size = 20;
                parTelefono.Value = OBJ.Telefono;
                cmd.Parameters.Add(parTelefono);

                SqlParameter parRol = new SqlParameter();
                parRol.ParameterName = "@rol";
                parRol.SqlDbType = SqlDbType.NVarChar;
                parRol.Size = 50;
                parRol.Value = OBJ.Rol;
                cmd.Parameters.Add(parRol);

                SqlParameter parPassword = new SqlParameter();
                parPassword.ParameterName = "@password";
                parPassword.SqlDbType = SqlDbType.NVarChar;
                parPassword.Size = 20;
                parPassword.Value = OBJ.Password;
                cmd.Parameters.Add(parPassword);

                respuesta = cmd.ExecuteNonQuery() == 1 ? "Ok" : "No se pudo editar valores";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (sqlcon.State == ConnectionState.Open)
                    sqlcon.Close();
            }
            return respuesta;
        }
        public static string Eliminar(CD_Empleado OBJ)
        {
            string respuesta = "";
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);

            try
            {
                sqlcon.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_EliminarEmpleados";
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter parId = new SqlParameter();
                parId.ParameterName = "@id";
                parId.SqlDbType = SqlDbType.Int;
                parId.Value = OBJ.Id;
                cmd.Parameters.Add(parId);

                respuesta = cmd.ExecuteNonQuery() == 1 ? "Ok" : "No se pudo eliminar valores";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (sqlcon.State == ConnectionState.Open)
                    sqlcon.Close();
            }
            return respuesta;
        }

    }
}
