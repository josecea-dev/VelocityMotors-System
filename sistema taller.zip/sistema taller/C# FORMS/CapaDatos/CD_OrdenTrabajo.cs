﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
namespace CapaDatos
{
    public class CD_OrdenTrabajo
    {

        private int _id;
        private DateTime fecha_registro;
        private string _nombre;
        private DateTime fecha_salida;
        private string _estado;
        private string _observaciones;
        private int _idVehiculo;
        private int _idEmpleado;
        private string _buscar;
        private int _cantidad;
        private decimal _precio;
        private int _idServicio;
        private string _nombreServicio;


        public int Id { get => _id; set => _id = value; }
        public DateTime Fecha_registro { get => fecha_registro; set => fecha_registro = value; }
        public string Nombre { get => _nombre; set => _nombre = value; }
        public DateTime Fecha_salida { get => fecha_salida; set => fecha_salida = value; }
        public string Estado { get => _estado; set => _estado = value; }
        public string Observaciones { get => _observaciones; set => _observaciones = value; }
        public int IdVehiculo { get => _idVehiculo; set => _idVehiculo = value; }
        public int IdEmpleado { get => _idEmpleado; set => _idEmpleado = value; }
        public string Buscar { get => _buscar; set => _buscar = value; }
        public int Cantidad { get => _cantidad; set => _cantidad = value; }
        public decimal Precio { get => _precio; set => _precio = value; }
        public int IdServicio { get => _idServicio; set => _idServicio = value; }
        public string NombreServicio { get => _nombreServicio; set => _nombreServicio = value; }

        public CD_OrdenTrabajo()
        {

        }
        public CD_OrdenTrabajo(int id, DateTime fecha_registro, string nombre, DateTime fecha_salida, string estado, string observaciones, int id_vehiculo, int id_empleado, string buscar, int cantidad, decimal precio, int idServicio, string nombreServicio)
        {
            this.Id = id;
            this.Fecha_registro = fecha_registro;
            this.Nombre = nombre;
            this.Fecha_salida = fecha_salida;
            this.Estado = estado;
            this.Observaciones = observaciones;
            this.IdEmpleado = id_empleado;
            this.IdVehiculo = id_vehiculo;
            this.Buscar = buscar;
            this.Cantidad = cantidad;
            this.Precio = precio;
            this.IdServicio = idServicio;
            this.NombreServicio = nombreServicio;
        }

        public DataTable TotalOrdenes()
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            DataTable table = new DataTable("OrdenTrabajo");

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_OrdenesTotales";
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter dta = new SqlDataAdapter(cmd);
                dta.Fill(table);
            }
            catch (Exception ex)
            {
                table = null;
            }
            return table;
        }
        public DataTable Mostrar()
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            DataTable table = new DataTable("OrdenTrabajo");

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_TablaDashboard";
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter dta = new SqlDataAdapter(cmd);
                dta.Fill(table);
            }
            catch (Exception ex)
            {
                table = null;
            }
            return table;
        }
        public static DataTable buscar(CD_OrdenTrabajo OBJ)
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            DataTable table = new DataTable("OrdenTrabajo");

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_BuscarCards";
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter parBuscar = new SqlParameter();
                parBuscar.ParameterName = "@buscar";
                parBuscar.SqlDbType = SqlDbType.NVarChar;
                parBuscar.Size = 50;
                parBuscar.Value = OBJ.Buscar;
                cmd.Parameters.Add(parBuscar);

                SqlDataAdapter dta = new SqlDataAdapter(cmd);
                dta.Fill(table);
            }
            catch (Exception ex)
            {
                table = null;
            }
            return table;
        }
        public DataTable mostrar_cards()
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            DataTable table = new DataTable("OrdenTrabajo");

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_MostrarCards";
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter dta = new SqlDataAdapter(cmd);
                dta.Fill(table);
            }
            catch (Exception ex)
            {
                table = null;
            }
            return table;
        }
        public static string InsertarCards(CD_OrdenTrabajo OBJ)
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            string respuesta = "";
            try
            {
                sqlcon.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_InsertarCards";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@estado", OBJ.Estado);
                cmd.Parameters.AddWithValue("@observaciones", OBJ.Observaciones);
                cmd.Parameters.AddWithValue("@id_vehiculo", OBJ.IdVehiculo);
                cmd.Parameters.AddWithValue("@id_empleado", OBJ.IdEmpleado);

               
                cmd.Parameters.AddWithValue("@cantidad", OBJ.Cantidad);
                cmd.Parameters.AddWithValue("@precio", OBJ.Precio);
                cmd.Parameters.AddWithValue("@id_servicio", OBJ.IdServicio);

                respuesta = cmd.ExecuteNonQuery() >= 2 ? "Ok" : "No se pudieron insertar todos los registros";
            }
            catch (Exception ex)
            {
                respuesta = ex.Message;
            }
            finally
            {
                if (sqlcon.State == ConnectionState.Open) sqlcon.Close();
            }
            return respuesta;
        }
    }
}
