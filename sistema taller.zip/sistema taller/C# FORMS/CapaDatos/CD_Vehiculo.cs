﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace CapaDatos
{
    public class CD_Vehiculo
    {
        private int _idVehiculo;
        private string _placa;
        private string _marca;
        private string _modelo;
        private int _anio;
        private int _idCliente;
        private string _buscar;

        public int IdVehiculo { get => _idVehiculo; set => _idVehiculo = value; }
        public string Placa { get => _placa; set => _placa = value; }
        public string Marca { get => _marca; set => _marca = value; }
        public string Modelo { get => _modelo; set => _modelo = value; }
        public int Anio { get => _anio; set => _anio = value; }
        public int IdCliente { get => _idCliente; set => _idCliente = value; }
        public string Buscar { get => _buscar; set => _buscar = value; }

        public CD_Vehiculo() { }

        public CD_Vehiculo(int idVehiculo, string placa, string marca, string modelo, int anio, int idCliente, string buscar)
        {
            this.IdVehiculo = idVehiculo;
            this.Placa = placa;
            this.Marca = marca;
            this.Modelo = modelo;
            this.Anio = anio;
            this.IdCliente = idCliente;
            this.Buscar = buscar;
        }

        public DataTable mostrar()
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            DataTable tabla = new DataTable("Vehiculo");
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_MostrarVehiculo";
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter dta = new SqlDataAdapter(cmd);
                dta.Fill(tabla);
            }
            catch (Exception)
            {
                tabla = null;
            }
            return tabla;
        }

        public static DataTable buscar(CD_Vehiculo OBJ)
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            DataTable tabla = new DataTable("Vehiculo");
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_BuscarVehiculo"; 
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter parBuscar = new SqlParameter();
                parBuscar.ParameterName = "@marca";
                parBuscar.SqlDbType = SqlDbType.NVarChar;
                parBuscar.Size = 50;
                parBuscar.Value = OBJ.Buscar;
                cmd.Parameters.Add(parBuscar);

                SqlDataAdapter dta = new SqlDataAdapter(cmd);
                dta.Fill(tabla);
            }
            catch (Exception)
            {
                tabla = null;
            }
            return tabla;
        }

        public static string insertar(CD_Vehiculo OBJ)
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            string respuesta = "";
            try
            {
                sqlcon.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_InsertarVehiculo";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@placa", OBJ.Placa);
                cmd.Parameters.AddWithValue("@marca", OBJ.Marca);
                cmd.Parameters.AddWithValue("@modelo", OBJ.Modelo);
                cmd.Parameters.AddWithValue("@anio", OBJ.Anio);
                cmd.Parameters.AddWithValue("@id_cliente", OBJ.IdCliente);

                respuesta = cmd.ExecuteNonQuery() == 1 ? "Ok" : "No se insertaron los valores";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (sqlcon.State == ConnectionState.Open) sqlcon.Close();
            }
            return respuesta;
        }

        public static string Editar(CD_Vehiculo OBJ)
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            string respuesta = "";
            try
            {
                sqlcon.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_EditarVehiculo";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@id_vehiculo", OBJ.IdVehiculo);
                cmd.Parameters.AddWithValue("@placa", OBJ.Placa);
                cmd.Parameters.AddWithValue("@marca", OBJ.Marca);
                cmd.Parameters.AddWithValue("@modelo", OBJ.Modelo);
                cmd.Parameters.AddWithValue("@anio", OBJ.Anio);
                cmd.Parameters.AddWithValue("@id_cliente", OBJ.IdCliente);

                respuesta = cmd.ExecuteNonQuery() == 1 ? "Ok" : "No se editaron los valores";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (sqlcon.State == ConnectionState.Open) sqlcon.Close();
            }
            return respuesta;
        }

        public static string Eliminar(CD_Vehiculo OBJ)
        {
            SqlConnection sqlcon = new SqlConnection(cd_conexion.cn);
            string respuesta = "";
            try
            {
                sqlcon.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlcon;
                cmd.CommandText = "sp_EliminarVehiculo"; 
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@id_vehiculo", OBJ.IdVehiculo);

                respuesta = cmd.ExecuteNonQuery() == 1 ? "Ok" : "No se eliminaron los valores";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (sqlcon.State == ConnectionState.Open) sqlcon.Close();
            }
            return respuesta;
        }
    }
}
