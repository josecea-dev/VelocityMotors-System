﻿namespace CapaPresentacion
{
    partial class Frm_Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Separator1 = new Guna.UI2.WinForms.Guna2Separator();
            this.btln_Salir = new Guna.UI2.WinForms.Guna2Button();
            this.Pnl_botones = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Button7 = new Guna.UI2.WinForms.Guna2Button();
            this.btln_Servicios = new Guna.UI2.WinForms.Guna2Button();
            this.btln_Ordenes = new Guna.UI2.WinForms.Guna2Button();
            this.btln_Vehiculos = new Guna.UI2.WinForms.Guna2Button();
            this.btln_Clientes = new Guna.UI2.WinForms.Guna2Button();
            this.btln_Empleados = new Guna.UI2.WinForms.Guna2Button();
            this.btln_Inicio = new Guna.UI2.WinForms.Guna2Button();
            this.pnl_Logo = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_header = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.pnl_principal = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel1.SuspendLayout();
            this.Pnl_botones.SuspendLayout();
            this.pnl_Logo.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 20;
            this.guna2Elipse1.TargetControl = this;
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BorderRadius = 5;
            this.guna2Panel1.Controls.Add(this.guna2Separator1);
            this.guna2Panel1.Controls.Add(this.btln_Salir);
            this.guna2Panel1.Controls.Add(this.Pnl_botones);
            this.guna2Panel1.Controls.Add(this.pnl_Logo);
            this.guna2Panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel1.FillColor = System.Drawing.Color.Black;
            this.guna2Panel1.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(268, 667);
            this.guna2Panel1.TabIndex = 0;
            // 
            // guna2Separator1
            // 
            this.guna2Separator1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.guna2Separator1.BackColor = System.Drawing.Color.Transparent;
            this.guna2Separator1.Location = new System.Drawing.Point(0, 588);
            this.guna2Separator1.Name = "guna2Separator1";
            this.guna2Separator1.Size = new System.Drawing.Size(290, 16);
            this.guna2Separator1.TabIndex = 7;
            // 
            // btln_Salir
            // 
            this.btln_Salir.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btln_Salir.Animated = true;
            this.btln_Salir.BackColor = System.Drawing.Color.Transparent;
            this.btln_Salir.BorderRadius = 20;
            this.btln_Salir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btln_Salir.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btln_Salir.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btln_Salir.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btln_Salir.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btln_Salir.FillColor = System.Drawing.Color.Transparent;
            this.btln_Salir.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btln_Salir.ForeColor = System.Drawing.Color.White;
            this.btln_Salir.Image = global::CapaPresentacion.Properties.Resources.logout;
            this.btln_Salir.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btln_Salir.Location = new System.Drawing.Point(3, 603);
            this.btln_Salir.Name = "btln_Salir";
            this.btln_Salir.Size = new System.Drawing.Size(265, 52);
            this.btln_Salir.TabIndex = 6;
            this.btln_Salir.Text = "Salir";
            this.btln_Salir.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btln_Salir.TextOffset = new System.Drawing.Point(15, 0);
            this.btln_Salir.Click += new System.EventHandler(this.btln_Salir_Click);
            // 
            // Pnl_botones
            // 
            this.Pnl_botones.BackColor = System.Drawing.Color.Transparent;
            this.Pnl_botones.Controls.Add(this.guna2Button7);
            this.Pnl_botones.Controls.Add(this.btln_Servicios);
            this.Pnl_botones.Controls.Add(this.btln_Ordenes);
            this.Pnl_botones.Controls.Add(this.btln_Vehiculos);
            this.Pnl_botones.Controls.Add(this.btln_Clientes);
            this.Pnl_botones.Controls.Add(this.btln_Empleados);
            this.Pnl_botones.Controls.Add(this.btln_Inicio);
            this.Pnl_botones.Dock = System.Windows.Forms.DockStyle.Top;
            this.Pnl_botones.Location = new System.Drawing.Point(0, 100);
            this.Pnl_botones.Name = "Pnl_botones";
            this.Pnl_botones.Size = new System.Drawing.Size(268, 488);
            this.Pnl_botones.TabIndex = 1;
            // 
            // guna2Button7
            // 
            this.guna2Button7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.guna2Button7.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button7.BorderRadius = 20;
            this.guna2Button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button7.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button7.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button7.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button7.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button7.ForeColor = System.Drawing.Color.White;
            this.guna2Button7.Image = global::CapaPresentacion.Properties.Resources.logout;
            this.guna2Button7.Location = new System.Drawing.Point(-3, 488);
            this.guna2Button7.Name = "guna2Button7";
            this.guna2Button7.Size = new System.Drawing.Size(290, 52);
            this.guna2Button7.TabIndex = 6;
            this.guna2Button7.Text = "Salir";
            // 
            // btln_Servicios
            // 
            this.btln_Servicios.Animated = true;
            this.btln_Servicios.BorderRadius = 20;
            this.btln_Servicios.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btln_Servicios.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btln_Servicios.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btln_Servicios.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btln_Servicios.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btln_Servicios.Dock = System.Windows.Forms.DockStyle.Top;
            this.btln_Servicios.FillColor = System.Drawing.Color.Transparent;
            this.btln_Servicios.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btln_Servicios.ForeColor = System.Drawing.Color.White;
            this.btln_Servicios.Image = global::CapaPresentacion.Properties.Resources.servicios;
            this.btln_Servicios.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btln_Servicios.Location = new System.Drawing.Point(0, 260);
            this.btln_Servicios.Name = "btln_Servicios";
            this.btln_Servicios.Size = new System.Drawing.Size(268, 52);
            this.btln_Servicios.TabIndex = 5;
            this.btln_Servicios.Text = "Servicios";
            this.btln_Servicios.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btln_Servicios.TextOffset = new System.Drawing.Point(15, 0);
            this.btln_Servicios.Click += new System.EventHandler(this.btln_Servicios_Click);
            // 
            // btln_Ordenes
            // 
            this.btln_Ordenes.Animated = true;
            this.btln_Ordenes.BorderRadius = 20;
            this.btln_Ordenes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btln_Ordenes.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btln_Ordenes.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btln_Ordenes.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btln_Ordenes.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btln_Ordenes.Dock = System.Windows.Forms.DockStyle.Top;
            this.btln_Ordenes.FillColor = System.Drawing.Color.Transparent;
            this.btln_Ordenes.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btln_Ordenes.ForeColor = System.Drawing.Color.White;
            this.btln_Ordenes.Image = global::CapaPresentacion.Properties.Resources.ordenes;
            this.btln_Ordenes.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btln_Ordenes.Location = new System.Drawing.Point(0, 208);
            this.btln_Ordenes.Name = "btln_Ordenes";
            this.btln_Ordenes.Size = new System.Drawing.Size(268, 52);
            this.btln_Ordenes.TabIndex = 4;
            this.btln_Ordenes.Text = "Órdenes";
            this.btln_Ordenes.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btln_Ordenes.TextOffset = new System.Drawing.Point(15, 0);
            this.btln_Ordenes.Click += new System.EventHandler(this.btln_Ordenes_Click);
            // 
            // btln_Vehiculos
            // 
            this.btln_Vehiculos.Animated = true;
            this.btln_Vehiculos.BorderRadius = 20;
            this.btln_Vehiculos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btln_Vehiculos.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btln_Vehiculos.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btln_Vehiculos.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btln_Vehiculos.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btln_Vehiculos.Dock = System.Windows.Forms.DockStyle.Top;
            this.btln_Vehiculos.FillColor = System.Drawing.Color.Transparent;
            this.btln_Vehiculos.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btln_Vehiculos.ForeColor = System.Drawing.Color.White;
            this.btln_Vehiculos.Image = global::CapaPresentacion.Properties.Resources.vehiculo;
            this.btln_Vehiculos.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btln_Vehiculos.Location = new System.Drawing.Point(0, 156);
            this.btln_Vehiculos.Name = "btln_Vehiculos";
            this.btln_Vehiculos.Size = new System.Drawing.Size(268, 52);
            this.btln_Vehiculos.TabIndex = 3;
            this.btln_Vehiculos.Text = "Vehículos";
            this.btln_Vehiculos.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btln_Vehiculos.TextOffset = new System.Drawing.Point(15, 0);
            this.btln_Vehiculos.Click += new System.EventHandler(this.guna2Button3_Click);
            // 
            // btln_Clientes
            // 
            this.btln_Clientes.Animated = true;
            this.btln_Clientes.BorderRadius = 20;
            this.btln_Clientes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btln_Clientes.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btln_Clientes.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btln_Clientes.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btln_Clientes.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btln_Clientes.Dock = System.Windows.Forms.DockStyle.Top;
            this.btln_Clientes.FillColor = System.Drawing.Color.Transparent;
            this.btln_Clientes.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btln_Clientes.ForeColor = System.Drawing.Color.White;
            this.btln_Clientes.Image = global::CapaPresentacion.Properties.Resources.user_white;
            this.btln_Clientes.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btln_Clientes.Location = new System.Drawing.Point(0, 104);
            this.btln_Clientes.Name = "btln_Clientes";
            this.btln_Clientes.Size = new System.Drawing.Size(268, 52);
            this.btln_Clientes.TabIndex = 2;
            this.btln_Clientes.Text = "Clientes";
            this.btln_Clientes.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btln_Clientes.TextOffset = new System.Drawing.Point(15, 0);
            this.btln_Clientes.Click += new System.EventHandler(this.btln_Clientes_Click);
            // 
            // btln_Empleados
            // 
            this.btln_Empleados.Animated = true;
            this.btln_Empleados.BorderRadius = 20;
            this.btln_Empleados.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btln_Empleados.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btln_Empleados.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btln_Empleados.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btln_Empleados.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btln_Empleados.Dock = System.Windows.Forms.DockStyle.Top;
            this.btln_Empleados.FillColor = System.Drawing.Color.Transparent;
            this.btln_Empleados.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btln_Empleados.ForeColor = System.Drawing.Color.White;
            this.btln_Empleados.Image = global::CapaPresentacion.Properties.Resources.empleados;
            this.btln_Empleados.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btln_Empleados.Location = new System.Drawing.Point(0, 52);
            this.btln_Empleados.Name = "btln_Empleados";
            this.btln_Empleados.Size = new System.Drawing.Size(268, 52);
            this.btln_Empleados.TabIndex = 1;
            this.btln_Empleados.Text = "Empleados";
            this.btln_Empleados.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btln_Empleados.TextOffset = new System.Drawing.Point(15, 0);
            this.btln_Empleados.Click += new System.EventHandler(this.btln_Empleados_Click);
            // 
            // btln_Inicio
            // 
            this.btln_Inicio.Animated = true;
            this.btln_Inicio.BorderRadius = 20;
            this.btln_Inicio.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btln_Inicio.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btln_Inicio.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btln_Inicio.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btln_Inicio.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btln_Inicio.Dock = System.Windows.Forms.DockStyle.Top;
            this.btln_Inicio.FillColor = System.Drawing.Color.Transparent;
            this.btln_Inicio.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btln_Inicio.ForeColor = System.Drawing.Color.White;
            this.btln_Inicio.Image = global::CapaPresentacion.Properties.Resources.home;
            this.btln_Inicio.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btln_Inicio.Location = new System.Drawing.Point(0, 0);
            this.btln_Inicio.Name = "btln_Inicio";
            this.btln_Inicio.Size = new System.Drawing.Size(268, 52);
            this.btln_Inicio.TabIndex = 0;
            this.btln_Inicio.Text = "Inicio";
            this.btln_Inicio.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btln_Inicio.TextOffset = new System.Drawing.Point(15, 0);
            this.btln_Inicio.Click += new System.EventHandler(this.btln_Inicio_Click);
            // 
            // pnl_Logo
            // 
            this.pnl_Logo.BackColor = System.Drawing.Color.Transparent;
            this.pnl_Logo.Controls.Add(this.guna2HtmlLabel1);
            this.pnl_Logo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Logo.Location = new System.Drawing.Point(0, 0);
            this.pnl_Logo.Name = "pnl_Logo";
            this.pnl_Logo.Size = new System.Drawing.Size(268, 100);
            this.pnl_Logo.TabIndex = 0;
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.AutoSize = false;
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(0, 0);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(268, 100);
            this.guna2HtmlLabel1.TabIndex = 0;
            this.guna2HtmlLabel1.Text = "Velocity Motors";
            this.guna2HtmlLabel1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.lbl_header);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(268, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(891, 100);
            this.panel1.TabIndex = 2;
            // 
            // lbl_header
            // 
            this.lbl_header.AutoSize = false;
            this.lbl_header.BackColor = System.Drawing.Color.Transparent;
            this.lbl_header.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_header.Font = new System.Drawing.Font("Microsoft YaHei", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_header.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_header.ImeMode = System.Windows.Forms.ImeMode.AlphaFull;
            this.lbl_header.Location = new System.Drawing.Point(0, 0);
            this.lbl_header.Name = "lbl_header";
            this.lbl_header.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.lbl_header.Size = new System.Drawing.Size(891, 100);
            this.lbl_header.TabIndex = 0;
            this.lbl_header.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_header.Click += new System.EventHandler(this.guna2HtmlLabel2_Click);
            // 
            // pnl_principal
            // 
            this.pnl_principal.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnl_principal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_principal.Location = new System.Drawing.Point(268, 100);
            this.pnl_principal.Name = "pnl_principal";
            this.pnl_principal.Size = new System.Drawing.Size(891, 567);
            this.pnl_principal.TabIndex = 3;
            // 
            // Frm_Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1159, 667);
            this.Controls.Add(this.pnl_principal);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.guna2Panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Frm_Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Frm_Dashboard";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Frm_Dashboard_Load);
            this.guna2Panel1.ResumeLayout(false);
            this.Pnl_botones.ResumeLayout(false);
            this.pnl_Logo.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2Panel Pnl_botones;
        private Guna.UI2.WinForms.Guna2Panel pnl_Logo;
        private Guna.UI2.WinForms.Guna2Button btln_Inicio;
        private Guna.UI2.WinForms.Guna2Button btln_Ordenes;
        private Guna.UI2.WinForms.Guna2Button btln_Vehiculos;
        private Guna.UI2.WinForms.Guna2Button btln_Clientes;
        private Guna.UI2.WinForms.Guna2Button btln_Empleados;
        private Guna.UI2.WinForms.Guna2Button btln_Servicios;
        private Guna.UI2.WinForms.Guna2Button btln_Salir;
        private Guna.UI2.WinForms.Guna2Button guna2Button7;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbl_header;
        private Guna.UI2.WinForms.Guna2Panel pnl_principal;
    }
}