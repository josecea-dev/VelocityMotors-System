﻿using CapaPresentacion.Interfaces_de_usuario;
using CapaPresentacion.tablas_CRUD;
using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class Frm_Dashboard : Form
    {
        public Frm_Dashboard()
        {
            InitializeComponent();
        }
        private Form formActivo = null;
        private void AbrirFormHijo(Form formHijo)
        {
            if (formActivo != null)
                formActivo.Close();

            formActivo = formHijo;
            formHijo.TopLevel = false;
            formHijo.FormBorderStyle = FormBorderStyle.None;
            formHijo.Dock = DockStyle.Fill;
            pnl_principal.Controls.Add(formHijo);
            formHijo.BringToFront();
            formHijo.Show();
        }
        private void guna2Button3_Click(object sender, EventArgs e)
        {
            this.Boton_presionado(sender, e);
            this.lbl_header.Text = "Vehiculos";
            this.AbrirFormHijo(new Frm_vehiculo());
        }

        private void btln_Salir_Click(object sender, EventArgs e)
        {
            this.Boton_presionado(sender, e);

            this.Hide();

            frm_login frm = new frm_login();
            frm.Show();
        }
        public void Boton_presionado(object sender ,EventArgs e)
        {
            Guna2Button boton = (Guna2Button)sender;

            foreach (Control control in Pnl_botones.Controls)
            {
                if (control is Guna2Button btn)
                {
                    btn.FillColor = Color.Black;
                    btn.ForeColor = Color.WhiteSmoke;
                }
            }
            boton.FillColor = Color.FromArgb(28, 28, 30);
            boton.ForeColor = Color.Gainsboro;

        }
        private void Frm_Dashboard_Load(object sender, EventArgs e)
        {
            this.AbrirFormHijo(new frm_inicio());



        }

        private void btln_Inicio_Click(object sender, EventArgs e)
        {
            this.Boton_presionado(sender, e);
            this.lbl_header.Text = "Inicio";
            this.AbrirFormHijo(new frm_inicio());
        }

        private void btln_Empleados_Click(object sender, EventArgs e)
        {
            this.Boton_presionado(sender, e);
            this.lbl_header.Text = "Empleados";
            this.AbrirFormHijo(new Frm_Empleado());
        }

        private void btln_Clientes_Click(object sender, EventArgs e)
        {
            this.Boton_presionado(sender, e);
            this.lbl_header.Text = "Clientes";
            this.AbrirFormHijo(new Frm_Clientes());
        }

        private void btln_Ordenes_Click(object sender, EventArgs e)
        {
            this.Boton_presionado(sender, e);
            this.lbl_header.Text = "Ordenes";
            this.AbrirFormHijo(new FrmOrdenes());
        }

        private void btln_Servicios_Click(object sender, EventArgs e)
        {
            this.Boton_presionado(sender, e);
            this.lbl_header.Text = "Servicios";
            this.AbrirFormHijo(new Frm_Servicio());
        }

        private void guna2HtmlLabel2_Click(object sender, EventArgs e)
        {

        }
    }
}
