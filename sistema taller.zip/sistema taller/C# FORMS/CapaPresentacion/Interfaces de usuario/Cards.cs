﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion.Interfaces_de_usuario
{
    public partial class Cards : UserControl
    {
        public Cards()
        {
            InitializeComponent();
        }

        private void Cards_Load(object sender, EventArgs e)
        {

        }
        public void TarjetasBD(int id, DateTime fecha, string estado, string observaciones, string placa, string nombre_empleado, decimal subtotal)
        {

            this.lblOrden.Text = $"Orden: #{id}";
            this.lblAsunto.Text = observaciones;
            this.lblEstado.Text = "Estado: " + estado;
            this.lblIngreso.Text = "Ingreso " + fecha.ToString("MM:dd:yyyy");
            this.lblVehiculo.Text = "Vehículo: " + placa;
            this.lblMecanico.Text = "Mecanico: " + nombre_empleado;
            this.lblTotal.Text = "SubTotal: " + subtotal;

            if (estado == "Pendiente")
            {
                this.Imagen.Image = Properties.Resources.pendiente;
            }
            else if (estado == "En proceso")
            {
                this.Imagen.Image = Properties.Resources.en_proceso;
            }
            else
            {
                this.Imagen.Image = Properties.Resources.check;
            }
        }

        private void fecha_ingreso_Click(object sender, EventArgs e)
        {

        }

        private void guna2HtmlLabel1_Click(object sender, EventArgs e)
        {

        }
    }
}
