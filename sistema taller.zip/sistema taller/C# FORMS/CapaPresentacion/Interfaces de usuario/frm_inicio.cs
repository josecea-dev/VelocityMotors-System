﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;
namespace CapaPresentacion
{
    public partial class frm_inicio : Form
    {
        public frm_inicio()
        {
            InitializeComponent();
        }
        public void ExtraerGanacias()
        {
            try
            {
                DataTable dta = CN_DetalleOrden.ExtraerGanacias();

                if (dta != null && dta.Rows.Count > 0)
                {
                    decimal Valor = Convert.ToDecimal(dta.Rows[0]["GanaciasTotales"].ToString());
                    lbl_ganacias.Text = $"${Valor.ToString()}";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        private void frm_inicio_Load(object sender, EventArgs e)
        {
            this.ExtraerGanacias();
            this.PorcentajeDeMeta();
            this.Mostrar();
        }
        public void Mostrar()
        {
            this.guna2DataGridView1.DataSource = CN_OrdenTrabajo.mostrar();
        }
        private void guna2Panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        public void PorcentajeDeMeta()
        {
            try
            {
                DataTable valor = CN_OrdenTrabajo.TotalOrdenes();

                if (valor.Rows.Count < 0 || valor == null)
                {
                    return;
                }
                if (valor.Rows.Count > 0 && valor != null)
                {
                    int cantidad_pedidos = Convert.ToInt32(valor.Rows[0]["OrdenesTotales"]);

                    int porcentaje = CN_OrdenTrabajo.MetaOrdenes(cantidad_pedidos);


                    guna2CircleProgressBar1.Value = porcentaje;
                    guna2CircleProgressBar1.Text = porcentaje.ToString();
                    this.guna2HtmlLabel2.Text = $"META DE PEDIDOS: 27";


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        private void guna2HtmlLabel2_Click(object sender, EventArgs e)
        {

        }

        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
