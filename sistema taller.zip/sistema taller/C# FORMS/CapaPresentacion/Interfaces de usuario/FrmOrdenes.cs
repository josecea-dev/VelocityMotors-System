﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using CapaNegocio;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion.Interfaces_de_usuario
{
    public partial class FrmOrdenes : Form
    {
        public FrmOrdenes()
        {
            InitializeComponent();
        }
        public void CargarCardsBD()
        {

            flowLayoutPanel1.Controls.Clear();

            try
            {
                DataTable dta = CN_OrdenTrabajo.mostrarCards();

                if (dta.Rows.Count < 0 || dta == null)
                {
                    return;
                }

                foreach (DataRow row in dta.Rows)
                {
                    //sacamos los valores de cada fila de la tabla
                    int id = Convert.ToInt32(row["id_OrdenTrabajo"]);
                    DateTime fecha = Convert.ToDateTime(row["fecha_ingreso"]);
                    string estado = Convert.ToString(row["estado"]);
                    string observaciones = Convert.ToString(row["observaciones"]);
                    string placa = Convert.ToString(row["placa"]);
                    string nombre_empleado = Convert.ToString(row["nombres"]);
                    decimal subtotal = Convert.ToDecimal(row["subtotal"]);

                    Cards tarjetas = new Cards();
                    tarjetas.TarjetasBD(id, fecha, estado, observaciones, placa, nombre_empleado, subtotal);

                    flowLayoutPanel1.Controls.Add(tarjetas);
                }
                    

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        private void FrmOrdenes_Load(object sender, EventArgs e)
        {
            this.CargarCardsBD();
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtBuscar.Text))
            {
                this.CargarCardsBD();
            }
        }
        public void Buscar()
        {
            try
            {
                if (string.IsNullOrEmpty(txtBuscar.Text))
                {
                    MessageBox.Show("No se aceptan cadenas vacias", "System", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                DataTable dta = CN_OrdenTrabajo.buscar(txtBuscar.Text);

                if (dta == null)
                {
                    return;
                }
                flowLayoutPanel1.Controls.Clear();
                foreach (DataRow row in dta.Rows)
                {
                    //sacamos los valores de cada fila de la tabla
                    int id = Convert.ToInt32(row["id_OrdenTrabajo"]);
                    DateTime fecha = Convert.ToDateTime(row["fecha_ingreso"]);
                    string estado = Convert.ToString(row["estado"]);
                    string observaciones = Convert.ToString(row["observaciones"]);
                    string placa = Convert.ToString(row["placa"]);
                    string nombre_empleado = Convert.ToString(row["nombres"]);
                    decimal subtotal = Convert.ToDecimal(row["subtotal"]);

                    Cards tarjetas = new Cards();
                    tarjetas.TarjetasBD(id, fecha, estado, observaciones, placa, nombre_empleado, subtotal);

                    flowLayoutPanel1.Controls.Add(tarjetas);
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            this.Buscar();
        }
        public void InsertarNuevaOrdenConDetalle()
        {
            try
            {
                string estado = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el estado: " + Environment.NewLine + "En proceso, Pendiente, Finalizado", "Estado de la Orden");

                if (estado != "En proceso" && estado != "Pendiente" && estado != "Finalizado")
                {
                    MessageBox.Show("El estado debe ser exactamente: 'En proceso', 'Pendiente' o 'Finalizado'.", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string observaciones = Microsoft.VisualBasic.Interaction.InputBox("Ingrese las observaciones del vehículo:", "Observaciones");
                string idVehiculoStr = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el ID numérico del Vehículo:", "ID Vehículo");
                string idEmpleadoStr = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el ID numérico del Empleado asignado:", "ID Empleado");

                string cantidadStr = Microsoft.VisualBasic.Interaction.InputBox("Ingrese la cantidad de servicios/repuestos:", "Cantidad", "1");
                string precioStr = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el precio unitario (Ej: 350.50):", "Precio");
                string idServicioStr = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el ID numérico del Servicio:", "ID Servicio");

                if (string.IsNullOrEmpty(estado) || string.IsNullOrEmpty(idVehiculoStr) || string.IsNullOrEmpty(idEmpleadoStr) ||
                    string.IsNullOrEmpty(cantidadStr) || string.IsNullOrEmpty(precioStr) || string.IsNullOrEmpty(idServicioStr))
                {
                    MessageBox.Show("Todos los campos numéricos y de estado son obligatorios.", "Campos Vacíos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int idVehiculo = Convert.ToInt32(idVehiculoStr);
                int idEmpleado = Convert.ToInt32(idEmpleadoStr);
                int cantidad = Convert.ToInt32(cantidadStr);
                decimal precio = Convert.ToDecimal(precioStr);
                int idServicio = Convert.ToInt32(idServicioStr);


                string respuesta = CN_OrdenTrabajo.InsertarCards(estado, observaciones, idVehiculo, idEmpleado, cantidad, precio, idServicio);

                if (respuesta == "Ok")
                {
                    MessageBox.Show("Orden de trabajo y detalle registrados con éxito.", "Velocity Motors", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.CargarCardsBD();
                }
                else
                {
                    MessageBox.Show("Error al registrar: " + respuesta, "Velocity Motors", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Error de formato: Asegúrese de ingresar números válidos en los IDs, la cantidad y el precio.", "Error de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrió un error inesperado: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void guna2GradientButton2_Click(object sender, EventArgs e)
        {
            this.InsertarNuevaOrdenConDetalle();
        }
    }
}
