﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;

namespace CapaPresentacion
{
    public partial class frm_login : Form
    {
        public frm_login()
        {
            InitializeComponent();
        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        public void Login()
        {
            try
            {
                if (string.IsNullOrEmpty(txtCorreo.Text) || string.IsNullOrEmpty(txtContrasenia.Text))
                {
                    MessageBox.Show("No se aceptan cadenas vacias, por favor, llenelas", "System", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                string respuesta = CN_Empleado.Login(txtCorreo.Text, txtContrasenia.Text);

                if (respuesta == "Ok")
                {

                    Extraer_rol();

                    string rol = sesion_usuario.Rol_usuario;

                    MessageBox.Show($"Login exitoso", "System", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.Hide();

                    Frm_Dashboard frm = new Frm_Dashboard();
                    frm.Show();
                }
                else
                {
                    MessageBox.Show($"Error: {respuesta}", "System", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace, "System", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void Extraer_rol()
        {
            try
            {
                DataTable dta = CN_Empleado.extraer_rol(txtCorreo.Text, txtContrasenia.Text);

                sesion_usuario.Rol_usuario = dta.Rows[0]["rol"].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace, "System", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            this.Login();
        }

        private void guna2ImageButton1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
