﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaPresentacion
{
    public class sesion_usuario
    {
        /*
        * Esta clase esta con la unica razon de extraer
        * el rol del usuario mediante el login, 
        * decidi ponerlo aqui para no romper la jerarquia de capas hechas
        */
        private static string rol_usuario;

        public static string Rol_usuario
        {
            get => rol_usuario;
            set => rol_usuario = value;
        }
    }
}
