﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;
namespace CapaPresentacion.tablas_CRUD
{
    public partial class Frm_Empleado : Form
    {
        public Frm_Empleado()
        {
            InitializeComponent();
        }
        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }
            if (guna2DataGridView1.Columns[e.ColumnIndex].Name == "Editar")
            {
                try
                {
                    //extraer datos de la bd mediante el datagrid
                    int id = Convert.ToInt32(guna2DataGridView1.Rows[e.RowIndex].Cells["id_empleado"].Value);
                    string cedulaActual = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["cedula"].Value);
                    string nombreActual = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["nombres"].Value);
                    string apellidoActual = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["apellidos"].Value);
                    string correoActual = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["correo"].Value);
                    string telefonoActual = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["telefono"].Value);
                    string rolActual = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["rol"].Value);
                    string passwordActual = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["password"].Value);

                    //pedir datos nuevos
                    string cedula = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el nuevo numero de cedula" + Environment.NewLine + "Ejemplo: 041-280799-1003L", "Editar cedula", cedulaActual);
                    string nombres = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el nuevo nombre", "Editar nombre", nombreActual);
                    string apellidos = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el nuevo apellido", "Editar apellido", apellidoActual);
                    string correo = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el nuevo correo electronico", "Editar correo", correoActual);
                    string telefono = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el nuevo numero de telefono", "Insertar numero telefonico", telefonoActual);
                    string rol = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el nuevo rol de su usuario" + Environment.NewLine + "Los roles que puede insertar: Administrador y Empleado", "Editar rol", rolActual);
                    string password = Microsoft.VisualBasic.Interaction.InputBox("Ingrese la contraseña nueva del empleado, debe de ser menos de 20 caracteres", "Editar password", passwordActual);

                    //validar la informacion del usuario, basicamente, si lo que pone es una cadena vacia, volvemos al valor anterior
                    if (string.IsNullOrEmpty(cedula))
                        cedula = cedulaActual; 
                    if (string.IsNullOrEmpty(nombres))
                        nombres = nombreActual;
                    if (string.IsNullOrEmpty(apellidos))
                        apellidos = apellidoActual;
                    if (string.IsNullOrEmpty(correo))
                        correo = correoActual;
                    if (string.IsNullOrEmpty(telefono))
                        telefono = telefonoActual;
                    if(string.IsNullOrEmpty(rol))
                        rol = rolActual;
                    if (string.IsNullOrEmpty(password))
                        password = passwordActual;

                    string respuesta = CN_Empleado.Editar(id, cedula, nombres, apellidos, correo, telefono, rol, password);

                    if (respuesta != "Ok")
                    {
                        MensajError($"Ups, hubo un error: {respuesta}");
                        return;
                    }
                    MensajOk("Los datos se han editado satisfactoriamente");
                    this.Mostrar();

                }
                catch (Exception ex)
                {
                    MensajError(ex.Message);
                }
            }
            if (guna2DataGridView1.Columns[e.ColumnIndex].Name == "Eliminar")
            {
                try
                {
                    int id = Convert.ToInt32(guna2DataGridView1.Rows[e.RowIndex].Cells["id_empleado"].Value);
                    string nombre = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["nombres"].Value);
                    string apellido = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["apellidos"].Value);

                    DialogResult opcion = MessageBox.Show($"¿Desea eliminar el empleado: {nombre + " " + apellido}", "System", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

                    if (opcion != DialogResult.OK)
                    {
                        MensajOk("Accion cancelada");
                        return;
                    }
                    string respuesta = CN_Empleado.Eliminar(id);

                    if (respuesta != "Ok")
                    {
                        MensajError($"Ups, hubo un error: {respuesta}");
                    }
                    MensajOk("El dato se ha eliminado exitosamente");
                    this.Mostrar();
                }
                catch (Exception ex)
                {
                    MensajError(ex.Message);
                }
            }
        }
        public void Mostrar()
        {
            this.guna2DataGridView1.DataSource = CN_Empleado.mostrar();
        }
        private void Frm_Empleado_Load(object sender, EventArgs e)
        {
            this.Mostrar();
            this.RolUsuario();
        }

        private void guna2DataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {

            //por un error en los colores, tuve que solucionarlo con codigo

            if (guna2DataGridView1.Columns[e.ColumnIndex].Name == "Editar")
            {
                e.Value = "Editar"; 
                e.CellStyle.BackColor = Color.WhiteSmoke; 
                e.CellStyle.ForeColor = Color.Black;

                e.CellStyle.SelectionBackColor = Color.WhiteSmoke;
                e.CellStyle.SelectionForeColor = Color.Black;
            }
            else if (guna2DataGridView1.Columns[e.ColumnIndex].Name == "Eliminar")
            {
                e.Value = "Eliminar"; 
                e.CellStyle.BackColor = Color.WhiteSmoke; 
                e.CellStyle.ForeColor = Color.Black;

                e.CellStyle.SelectionBackColor = Color.WhiteSmoke;
                e.CellStyle.SelectionForeColor = Color.Black;
            }
        }

        private void guna2DataGridView1_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
        {
            Cursor = Cursors.Hand;
        }
        public void Buscar()
        {
            try
            {

                if (string.IsNullOrEmpty(txtBuscar.Text))
                {
                    MessageBox.Show("No se aceptan valores vacios", "System", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                this.guna2DataGridView1.DataSource = CN_Empleado.buscar(txtBuscar.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        public void RolUsuario()
        {
            if (sesion_usuario.Rol_usuario != "Administrador")
            {
                this.guna2DataGridView1.Columns[0].Visible = false;
                this.guna2DataGridView1.Columns[1].Visible = false;
                this.guna2DataGridView1.Columns[10].Visible = false;
                this.guna2GradientButton2.Enabled = false;
            }
        }
        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            this.Buscar();
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtBuscar.Text))
            {
                this.guna2DataGridView1.DataSource = CN_Empleado.mostrar();
            }
        }
        public void MensajOk(string msg)
        {
            MessageBox.Show(msg, "System", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        public void MensajError(string msg)
        {
            MessageBox.Show(msg, "System", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        public void Insertar()
        {
            try
            {
                //pedir datos
                string cedula = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el numero de cedula" + Environment.NewLine + "Ejemplo: 041-280799-1003L", "Insertar cedula");
                string nombres = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el nombre", "Insertar nombre");
                string apellidos = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el apellido", "Insertar apellido");
                string correo = Microsoft.VisualBasic.Interaction.InputBox("Ingrese su correo electronico", "Insertar correo");
                string telefono = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el numero de telefono", "Insertar numero telefonico");
                string rol = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el rol de su usuario" + Environment.NewLine + "Los roles que puede insertar: Administrador y Empleado", "Insertar rol");
                string password = Microsoft.VisualBasic.Interaction.InputBox("Ingrese la contraseña del empleado, debe de ser menos de 20 caracteres", "Insertar password");

                //validar la solidez de los datos

                //asegurar que el usuario no ponga valores vacios
                if (string.IsNullOrEmpty(cedula) || string.IsNullOrEmpty(nombres) || string.IsNullOrEmpty(apellidos) || string.IsNullOrEmpty(correo) || string.IsNullOrEmpty(telefono) || string.IsNullOrEmpty(rol) || string.IsNullOrEmpty(password))
                {
                    MensajError("No se aceptan cadenas vacias");
                    return;
                }

                string respuesta = CN_Empleado.Insertar(cedula, nombres, apellidos, correo, telefono, rol, password);

                if (respuesta == "Ok")
                {
                    MensajOk("Los datos se han insertado correctamente");
                    this.Mostrar();
                }
                else
                {
                    MensajError($"Ups!, hubo un error: {respuesta}");
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        private void guna2GradientButton2_Click(object sender, EventArgs e)
        {
            this.Insertar();
        }
    }
}
