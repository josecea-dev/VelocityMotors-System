﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;
namespace CapaPresentacion.tablas_CRUD
{
    public partial class Frm_vehiculo : Form
    {
        public Frm_vehiculo()
        {
            InitializeComponent();
        }
        public void Mostrar()
        {
            this.guna2DataGridView1.DataSource = CN_Vehiculo.mostrar();
            this.guna2DataGridView1.Columns[2].Visible = false;
        }
        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            if (guna2DataGridView1.Columns[e.ColumnIndex].Name == "Editar")
            {
                try
                {
                    int idVehiculo = Convert.ToInt32(guna2DataGridView1.Rows[e.RowIndex].Cells["id_vehiculo"].Value);
                    string placaActual = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["placa"].Value);
                    string marcaActual = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["marca"].Value);
                    string modeloActual = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["modelo"].Value);
                    string anioActual = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["anio"].Value);
                    string idClienteActual = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["id_cliente"].Value);

                    string placa = Microsoft.VisualBasic.Interaction.InputBox("Modificar Placa:", "Editar Vehículo", placaActual);
                    string marca = Microsoft.VisualBasic.Interaction.InputBox("Modificar Marca:", "Editar Vehículo", marcaActual);
                    string modelo = Microsoft.VisualBasic.Interaction.InputBox("Modificar Modelo:", "Editar Vehículo", modeloActual);
                    string anioStr = Microsoft.VisualBasic.Interaction.InputBox("Modificar Año:", "Editar Vehículo", anioActual);
                    string idClienteStr = Microsoft.VisualBasic.Interaction.InputBox("Modificar ID del Cliente:", "Editar Vehículo", idClienteActual);

                    if (string.IsNullOrEmpty(placa)) placa = placaActual;
                    if (string.IsNullOrEmpty(marca)) marca = marcaActual;
                    if (string.IsNullOrEmpty(modelo)) modelo = modeloActual;
                    if (string.IsNullOrEmpty(anioStr)) anioStr = anioActual;
                    if (string.IsNullOrEmpty(idClienteStr)) idClienteStr = idClienteActual;

                    string respuesta = CN_Vehiculo.Editar(idVehiculo, placa, marca, modelo, Convert.ToInt32(anioStr), Convert.ToInt32(idClienteStr));

                    if (respuesta != "Ok")
                    {
                        MensajError($"Error: {respuesta}");
                        return;
                    }
                    MensajOk("Los datos del vehículo se actualizaron correctamente");
                    this.Mostrar();
                }
                catch (Exception ex)
                {
                    MensajError("Error en conversión de datos: " + ex.Message);
                }
            }

            if (guna2DataGridView1.Columns[e.ColumnIndex].Name == "Eliminar")
            {
                try
                {
                    int idVehiculo = Convert.ToInt32(guna2DataGridView1.Rows[e.RowIndex].Cells["id_vehiculo"].Value);
                    string placa = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["placa"].Value);

                    DialogResult opcion = MessageBox.Show($"¿Desea eliminar permanentemente el vehículo con placa [{placa}]?", "Velocity Motors", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

                    if (opcion != DialogResult.OK)
                    {
                        MensajOk("Eliminación cancelada");
                        return;
                    }

                    string respuesta = CN_Vehiculo.Eliminar(idVehiculo);

                    if (respuesta != "Ok")
                    {
                        MensajError($"Error: {respuesta}");
                        return;
                    }
                    MensajOk("El vehículo se removió correctamente");
                    this.Mostrar();
                }
                catch (Exception ex)
                {
                    MensajError($"Error al intentar eliminar: {ex.Message}");
                }
            }
        }
        public void MensajOk(string msg)
        {
            MessageBox.Show(msg, "System", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        public void MensajError(string msg)
        {
            MessageBox.Show(msg, "System", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        public void Buscar()
        {
            try
            {
                if (string.IsNullOrEmpty(txtBuscar.Text))
                {
                    MensajError("No se aceptan valores vacíos");
                    return;
                }
                this.guna2DataGridView1.DataSource = CN_Vehiculo.buscar(txtBuscar.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Frm_vehiculo_Load(object sender, EventArgs e)
        {
            this.Mostrar();
            this.RolUsuario();
        }

        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            this.Buscar();
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtBuscar.Text))
            {
                this.guna2DataGridView1.DataSource = CN_Vehiculo.mostrar();
            }
        }
        public void Insertar()
        {
            try
            {
                string placa = Microsoft.VisualBasic.Interaction.InputBox("Ingrese la placa del vehículo " + Environment.NewLine + "Ejemplo: M 123456", "Insertar Placa");
                string marca = Microsoft.VisualBasic.Interaction.InputBox("Ingrese la marca (Ej: Toyota)", "Insertar Marca");
                string modelo = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el modelo (Ej: Corolla)", "Insertar Modelo");
                string anioStr = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el año del vehículo", "Insertar Año");
                string idClienteStr = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el ID numérico del Cliente (Dueño)", "Asignar Propietario");

                if (string.IsNullOrEmpty(placa) || string.IsNullOrEmpty(marca) || string.IsNullOrEmpty(modelo) || string.IsNullOrEmpty(anioStr) || string.IsNullOrEmpty(idClienteStr))
                {
                    MensajError("No se aceptan campos vacíos");
                    return;
                }
                int anio;
                int idCliente;


                if (!int.TryParse(anioStr, out anio))
                {
                    MensajError("Escriba un año numerico valido");
                    return;
                }
                if (!int.TryParse(idClienteStr, out idCliente))
                {
                    MensajError("Escriba un año id numero valido valido");
                    return;
                }

                string respuesta = CN_Vehiculo.Insertar(placa, marca, modelo, anio, idCliente);

                if (respuesta != "Ok")
                {
                    MensajError($"Error: {respuesta}");
                    return;
                }
                MensajOk("Vehículo registrado con éxito en el sistema");
                this.Mostrar();
            }
            catch (Exception ex)
            {
                MensajError("Asegúrese de ingresar valores numéricos válidos en Año e ID Cliente. " + ex.Message);
            }
        }
        public void RolUsuario()
        {
            if (sesion_usuario.Rol_usuario != "Administrador")
            {
                this.guna2DataGridView1.Columns[0].Visible = false;
                this.guna2DataGridView1.Columns[1].Visible = false;
            }
        }
        private void guna2GradientButton2_Click(object sender, EventArgs e)
        {
            this.Insertar();
        }
    }
}
