﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;

namespace CapaPresentacion.tablas_CRUD
{
    public partial class Frm_Servicio : Form
    {
        public Frm_Servicio()
        {
            InitializeComponent();
        }
        public void Mostrar()
        {
            this.guna2DataGridView1.DataSource = CN_Servicio.Mostrar();
        }
        public void Buscar()
        {
            try
            {
                if (string.IsNullOrEmpty(txtBuscar.Text))
                {
                    MensajError("No se puede buscar elementos vacios");
                    return;
                }
                this.guna2DataGridView1.DataSource = CN_Servicio.buscar(txtBuscar.Text);
            }
            catch (Exception ex)
            {
                MensajError(ex.Message);
            }
        }
        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            this.Buscar();
        }
        public void MensajOk(string msg)
        {
            MessageBox.Show(msg, "System", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        public void MensajError(string msg)
        {
            MessageBox.Show(msg, "System", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void Frm_Servicio_Load(object sender, EventArgs e)
        {
            this.Mostrar();
            this.RolUsuario();
        }
        public void Insertar()
        {
            string respuesta = "";

            try
            {
                string nombre = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el nombre del servicio", "Nuevo nombre");
                string descripcion = Microsoft.VisualBasic.Interaction.InputBox("Ingrese la descripcion", "Nueva descripcion");
                string inputPrecio = Microsoft.VisualBasic.Interaction.InputBox("Escriba el precio" + Environment.NewLine + "Ejemplo: 43.22", "Agregar nuevo nombre");

                decimal precio;

                if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(descripcion) || string.IsNullOrEmpty(inputPrecio))
                {
                    MensajError("No se aceptan cadenas vacias");
                    return;
                }
                if (!decimal.TryParse(inputPrecio, out precio))
                {
                    MensajError("Por favor, escriba el precio en valor numerico");
                    return;
                }

                respuesta = CN_Servicio.Insertar(nombre, descripcion, precio);

                if (respuesta != "Ok")
                {
                    MensajError($"Error: {respuesta}");
                    return;
                }
                MensajOk("Se agregaron los valores");
                this.Mostrar();

            }
            catch (Exception ex)
            {
                MensajError(ex.Message);
            }
        }
        public void RolUsuario()
        {
            if (sesion_usuario.Rol_usuario != "Administrador")
            {
                this.guna2DataGridView1.Columns[0].Visible = false;
                this.guna2DataGridView1.Columns[1].Visible = false;
                this.guna2GradientButton2.Enabled = false;
            }
        }
        private void guna2GradientButton2_Click(object sender, EventArgs e)
        {
            this.Insertar();
        }
        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }
            if (e.RowIndex >= 0 && guna2DataGridView1.Columns[e.ColumnIndex].Name == "Editar")
            {
                try
                {
                    int id = Convert.ToInt32(guna2DataGridView1.Rows[e.RowIndex].Cells["id_servicio"].Value);
                    string nombreActual = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["nombre"].Value);
                    string descripcionActual = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["descripcion"].Value);
                    decimal precioActual = Convert.ToDecimal(guna2DataGridView1.Rows[e.RowIndex].Cells["precio"].Value);

                    //pedir valores
                    string nombre = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el nombre nuevo", "Nuevo nombre", nombreActual);
                    string descripcion = Microsoft.VisualBasic.Interaction.InputBox("Ingrese su descripcion nueva", "Nueva descripcion", descripcionActual);
                    string input_precio = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el precio nuevo"+ Environment.NewLine + "Ejemplo: 78.92", "Nuevo precio", precioActual.ToString());

                    decimal precio;

                    if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(descripcion) || string.IsNullOrEmpty(input_precio))
                    {
                        MensajError("no se aceptan valores vacios");
                        return;
                    }
                    if (!decimal.TryParse(input_precio, out precio))
                    {
                        MensajError("Por favor, escriba un valor numerico");
                        return;
                    }

                    string respuesta = CN_Servicio.Editar(id, nombre, descripcion, precio);

                    if (respuesta != "Ok")
                    {
                        MensajError($"Error: {respuesta}");
                        return;
                    }
                    MensajOk("Los datos han sido actualizados correctamente");
                    this.Mostrar();

                }
                catch (Exception ex)
                {
                    MensajError(ex.Message + ex.StackTrace);
                }
            }
            if (e.RowIndex >= 0 && guna2DataGridView1.Columns[e.ColumnIndex].Name == "Eliminar")
            {
                try
                {
                    int id = Convert.ToInt32(guna2DataGridView1.Rows[e.RowIndex].Cells["id_servicio"].Value);
                    string nombreActual = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["nombre"].Value);

                    DialogResult opcion = MessageBox.Show($"¿Desea eliminar el valor: {nombreActual}?", "System", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

                    if (opcion != DialogResult.OK)
                    {
                        MensajOk("Accion cancelada");
                        return;
                    }
                    string respuesta = CN_Servicio.Eliminar(id);

                    if (respuesta != "Ok")
                    {
                        MensajError($"Error: {respuesta}");
                        return;
                    }
                    MensajOk("El dato ha sido eliminado");
                    this.Mostrar();

                }
                catch (Exception ex)
                {
                    MensajError(ex.Message + ex.StackTrace);
                }
            }
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtBuscar.Text))
                this.Mostrar();
        }
    }
}
