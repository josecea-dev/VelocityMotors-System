﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;

namespace CapaPresentacion.tablas_CRUD
{
    public partial class Frm_Clientes : Form
    {
        public Frm_Clientes()
        {
            InitializeComponent();
        }
        public void Mostrar()
        {
            this.guna2DataGridView1.DataSource = CN_Cliente.mostrar();
        }
        private void Frm_Clientes_Load(object sender, EventArgs e)
        {
            this.Mostrar();
            this.RolUsuario();
        }

        private void guna2DataGridView1_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
        {
            this.Cursor = Cursors.Hand;
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtBuscar.Text))
                this.guna2DataGridView1.DataSource = CN_Cliente.mostrar();
        }
        public void MensajOk(string msg)
        {
            MessageBox.Show(msg, "System", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        public void MensajError(string msg)
        {
            MessageBox.Show(msg, "System", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        public void Buscar()
        {
            try
            {
                if (string.IsNullOrEmpty(txtBuscar.Text))
                {
                    MensajError("No se aceptan valores vacios");
                    return;
                }
                this.guna2DataGridView1.DataSource = CN_Cliente.buscar(txtBuscar.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            this.Buscar();
        }
        public void Insertar()
        {
            try
            {
                //pedir datos
                string cedula = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el numero de cedula" + Environment.NewLine + "Ejemplo: 041-280799-1003L", "Insertar cedula");
                string nombres = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el nombre", "Insertar nombre");
                string apellidos = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el apellido", "Insertar apellido");
                string correo = Microsoft.VisualBasic.Interaction.InputBox("Ingrese su correo electronico", "Insertar correo");
                string telefono = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el numero de telefono", "Insertar numero telefonico");

                //asegurar que el usuario no ponga valores vacios
                if (string.IsNullOrEmpty(cedula) || string.IsNullOrEmpty(nombres) || string.IsNullOrEmpty(apellidos) || string.IsNullOrEmpty(correo) || string.IsNullOrEmpty(telefono))
                {
                    MensajError("No se aceptan cadenas vacias");
                    return;
                }

                string respuesta = CN_Cliente.Insertar(cedula,nombres,apellidos,correo,telefono);

                if (respuesta != "Ok")
                {
                    MensajError($"Error: {respuesta}");
                    return;
                }
                MensajOk("Se han ingresado los valores correctamente");
                this.Mostrar();

            }
            catch(Exception ex)
            {
                MensajError(ex.Message);
            }
        }
        public void RolUsuario()
        {
            if (sesion_usuario.Rol_usuario != "Administrador")
            {
                this.guna2DataGridView1.Columns[0].Visible = false;
                this.guna2DataGridView1.Columns[1].Visible = false;
            }
        }
        private void guna2GradientButton2_Click(object sender, EventArgs e)
        {
            this.Insertar();
        }

        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }
            if (e.RowIndex >= 0 && guna2DataGridView1.Columns[e.ColumnIndex].Name == "Editar")
            {
                try
                {
                    int id = Convert.ToInt32(guna2DataGridView1.Rows[e.RowIndex].Cells["id_cliente"].Value);
                    string cedulaActual = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["cedula"].Value);
                    string nombreActual = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["nombres"].Value);
                    string apellidoActual = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["apellidos"].Value);
                    string correoActual = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["correo"].Value);
                    string telefonoActual = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["telefono"].Value);


                    string cedula = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el nuevo numero de cedula" + Environment.NewLine + "Ejemplo: 041-280799-1003L", "Editar cedula", cedulaActual);
                    string nombres = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el nuevo nombre", "Editar nombre", nombreActual);
                    string apellidos = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el nuevo apellido", "Editar apellido", apellidoActual);
                    string correo = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el nuevo correo electronico", "Editar correo", correoActual);
                    string telefono = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el nuevo numero de telefono", "Insertar numero telefonico", telefonoActual);


                    if (string.IsNullOrEmpty(cedula))
                        cedula = cedulaActual;
                    if (string.IsNullOrEmpty(nombres))
                        nombres = nombreActual;
                    if (string.IsNullOrEmpty(apellidos))
                        apellidos = apellidoActual;
                    if (string.IsNullOrEmpty(correo))
                        correo = correoActual;
                    if (string.IsNullOrEmpty(telefono))
                        telefono = telefonoActual;

                    string respuesta = CN_Cliente.Editar(id, cedula, nombres, apellidos, correo, telefono);

                    if (respuesta != "Ok")
                    {
                        MensajError($"Error: {respuesta}");
                        return;
                    }
                    MensajOk("se han editado los datos correctamente");
                    this.Mostrar();

                }
                catch (Exception ex)
                {
                    MensajError(ex.Message + ex.StackTrace);
                }
            }
            if (e.RowIndex > 0 && guna2DataGridView1.Columns[e.ColumnIndex].Name == "Eliminar")
            {
                try
                {
                    int id = Convert.ToInt32(guna2DataGridView1.Rows[e.RowIndex].Cells["id_cliente"].Value);
                    string nombre = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["nombres"].Value);
                    string apellido = Convert.ToString(guna2DataGridView1.Rows[e.RowIndex].Cells["apellidos"].Value);

                    DialogResult opcion = MessageBox.Show("¿Desea eliminar al usuario :" + nombre + " " + apellido, "System", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

                    if (opcion != DialogResult.OK)
                    {
                        MensajOk("accion cancelada");
                        return;
                    }
                    string respuesta = CN_Cliente.Eliminar(id);

                    if (respuesta != "Ok")
                    {
                        MensajError($"Error: {respuesta}");
                        return;
                    }
                    MensajOk("El valor ha sido eliminado");
                    this.Mostrar();

                }
                catch (Exception ex)
                {
                    MensajError($"Error: {ex.Message + ex.StackTrace}");
                }
            }
        }
    }
}
