USE VelocityMotors_BD;

--datos de pruebas
INSERT INTO dbo.Cliente (cedula, nombres, apellidos, correo, telefono)
VALUES 
('001-150505-1023A', 'Carlos', 'Gomez', 'carlos@gmail.com', '+50581234567'),
('001-220898-2045B', 'Maria', 'Lopez', 'maria@gmail.com', '+50582345678'),
('001-110700-3098C', 'Juan', 'Perez', 'juan@gmail.com', '+50583456789');

INSERT INTO dbo.Vehiculo (placa, marca, modelo, anio, id_cliente)
VALUES
('M 123-ABC', 'Toyota', 'Corolla', 2015, 1),
('M 456-DEF', 'Honda', 'Civic', 2018, 2),
('M 789-GHI', 'Nissan', 'Sentra', 2020, 3);

INSERT INTO dbo.Empleado (cedula, nombres, apellidos, correo, telefono, rol, password)
VALUES
('001-100100-1001A', 'Jose', 'Cea', 'josedanielestebancea9@gmail.com', '+50587917080', 'Administrador', 'jdec19'),
('001-200200-2002B', 'Pedro', 'Ramirez', 'pedro@taller.com', '+50570000002', 'Empleado', 'emp123'),
('001-300300-3003C', 'Ana', 'Lopez', 'ana@taller.com', '+50570000003', 'Empleado', 'emp456');

INSERT INTO dbo.OrdenTrabajo (estado, observaciones, id_vehiculo, id_empleado)
VALUES
('Pendiente', 'Cambio de aceite', 1, 2),
('En proceso', 'Revisi n de frenos', 2, 2),
('Finalizado', 'Mantenimiento general', 3, 3);

INSERT INTO dbo.Servicio (nombre, descripcion, precio)
VALUES
('Cambio de aceite', 'Cambio de aceite y filtro', 25.00),
('Revisi n de frenos', 'Chequeo completo del sistema de frenos', 40.00),
('Mantenimiento general', 'Revisi n completa del veh culo', 80.00);

INSERT INTO dbo.DetalleOrden (cantidad, precio, id_OrdenTrabajo, id_servicio)
VALUES
(1, 25.00, 1, 1),
(1, 40.00, 2, 2),
(1, 80.00, 3, 3);