USE VelocityMotors_BD;

--SCRIPS PROCEDIMIENTOS ALMACENADOS

--LOGIN
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_Login
@correo NVARCHAR(100),
@password NVARCHAR(20)
AS
SELECT correo, password
FROM dbo.Empleado
WHERE correo = @correo AND password = @password;

--Extraer rol
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_ExtrarRol
@correo NVARCHAR(100),
@password NVARCHAR(20)
AS
SELECT rol
FROM dbo.Empleado
WHERE correo = @correo AND password = @password;

--GANANCIAS 
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_ExtraerGanancias
AS
SELECT SUM(precio) AS GanaciasTotales
FROM dbo.DetalleOrden;

--Mostrar tabla empleados
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_MostarEmpleado
AS
SELECT*
FROM dbo.Empleado

--Buscar en tabla empleado mediante nombre
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_BuscarEmpleado
@nombres NVARCHAR(50)
AS
SELECT*
FROM dbo.Empleado
WHERE nombres LIKE '%' + @nombres + '%'

--insertar a la tabla empleado
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_InsertarEmpleado
@cedula NVARCHAR(20),
@nombres NVARCHAR(50),
@apellidos NVARCHAR(50),
@correo NVARCHAR(100),
@telefono NVARCHAR(20),
@rol NVARCHAR(20),
@password NVARCHAR(20)
AS
INSERT INTO dbo.Empleado(cedula, nombres, apellidos, correo, telefono, rol, password)
VALUES(@cedula, @nombres, @apellidos, @correo, @telefono, @rol, @password);

--editar en tabla empleado
SET QUOTED_IDENTIFIER ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_EditarEmpleado
@id INT,
@cedula NVARCHAR(20),
@nombres NVARCHAR(50),
@apellidos NVARCHAR(50),
@correo NVARCHAR(100),
@telefono NVARCHAR(20),
@rol NVARCHAR(20),
@password NVARCHAR(20)
AS
UPDATE dbo.Empleado
SET cedula = @cedula, nombres = @nombres, apellidos = @apellidos, correo = @correo, telefono = @telefono, rol = @rol, password = @password
WHERE id_empleado = @id;

--Eliminacion de los datos de la tabla empleados
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_EliminarEmpleados
@id INT
AS
DELETE FROM dbo.Empleado
WHERE id_empleado = @id;

--Eliminacion de los datos de la tabla empleados
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_OrdenesTotales
AS
SELECT COUNT(*) AS OrdenesTotales
FROM dbo.OrdenTrabajo 

--vista de datos para la pantalla de inicio
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_TablaDashboard
AS
SELECT (e.nombres + ' ' + e.apellidos) AS NombreCliente, 
	   o.estado AS Estado, 
	   o.observaciones as Observaciones, 
	   (v.marca + ' ' + v.modelo) AS DatosVehiculo, 
	   v.placa AS PlacaVehiculo
FROM dbo.OrdenTrabajo o
INNER JOIN dbo.Empleado e
	ON O.id_empleado = e.id_empleado
INNER JOIN dbo.Vehiculo v
	ON v.id_vehiculo = o.id_vehiculo

--proc para mostrar en tabla cliente
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_MostrarCliente
AS
SELECT*
FROM dbo.Cliente

--buscar en tabla cliente
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_BuscarCliente
@nombre NVARCHAR(50)
AS
SELECT*
FROM dbo.Cliente
WHERE nombres LIKE '%' + @nombre + '%'

--procedimiento para insertar en tabla cliente
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_InsertarCliente
@cedula NVARCHAR(20), 
@nombres NVARCHAR(50), 
@apellidos NVARCHAR(50), 
@correo NVARCHAR(100), 
@telefono NVARCHAR(20)
AS
INSERT INTO dbo.Cliente(cedula, nombres, apellidos, correo, telefono)
VALUES(@cedula, @nombres, @apellidos, @correo, @telefono);

--procedimiento para editar en tabla cliente
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_EditarCliente
@id INT,
@cedula NVARCHAR(20), 
@nombres NVARCHAR(50), 
@apellidos NVARCHAR(50), 
@correo NVARCHAR(100), 
@telefono NVARCHAR(20)
AS
UPDATE dbo.Cliente
SET cedula = @cedula, nombres = @nombres, apellidos = @apellidos, correo = @correo, telefono = @telefono
WHERE id_cliente = @id

--procedimiento para eliminar en tabla cliente
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_BorrarCliente
@id INT
AS
DELETE FROM dbo.Cliente
WHERE id_cliente = @id;

--procedimiento para mostrar en tabla vehiculo
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_MostrarVehiculo
AS
SELECT v.id_vehiculo, v.marca, v.modelo, v.placa, v.anio, v.id_cliente, (c.nombres + ' ' + c.apellidos) AS NombreCompleto
FROM dbo.Vehiculo v
INNER JOIN dbo.Cliente c
	ON v.id_cliente = c.id_cliente

--procedimiento almacenado de insertar
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_InsertarVehiculo
@placa NVARCHAR(10),
@marca NVARCHAR(50) ,
@modelo NVARCHAR(50),
@anio INT ,
@id_cliente INT
AS 
INSERT INTO dbo.Vehiculo(placa,marca,modelo,anio,id_cliente)
VALUES(@placa, @marca, @modelo, @anio, @id_cliente);

--proc para editar vehiculo
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_EditarVehiculo
@id_vehiculo INT,
@placa NVARCHAR(10),
@marca NVARCHAR(50) ,
@modelo NVARCHAR(50),
@anio INT ,
@id_cliente INT
AS 
UPDATE dbo.Vehiculo
SET placa = @placa, marca = @marca, modelo = @modelo, anio = @anio, id_cliente = @id_cliente
WHERE id_vehiculo = @id_vehiculo;

--proc para borrar vehiculo
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_EliminarVehiculo
@id_vehiculo INT
AS
DELETE FROM dbo.Vehiculo
WHERE id_vehiculo = @id_vehiculo;

--buscar en tabla vehiculo
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_BuscarVehiculo
@marca NVARCHAR(50)
AS
SELECT 
    v.id_vehiculo, 
    v.marca, 
    v.modelo, 
    v.placa, 
    v.anio, 
    v.id_cliente, 
    (c.nombres + ' ' + c.apellidos) AS NombreCompleto
FROM dbo.Vehiculo v
INNER JOIN dbo.Cliente c
    ON v.id_cliente = c.id_cliente
WHERE v.marca LIKE '%' + @marca + '%'; 

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_MostrarCards
AS
SELECT 
    O.id_OrdenTrabajo,
    O.fecha_ingreso,
    O.estado,
    O.observaciones,
    v.placa,
    e.nombres,
    s.nombre,
    D.cantidad,
    D.precio,
    D.subtotal
FROM dbo.OrdenTrabajo O
INNER JOIN dbo.DetalleOrden D 
	ON O.id_OrdenTrabajo = D.id_OrdenTrabajo
INNER JOIN dbo.Vehiculo v
	ON o.id_vehiculo = v.id_vehiculo
INNER JOIN dbo.Empleado e
	ON o.id_empleado = e.id_empleado
INNER JOIN dbo.Servicio s
	ON d.id_servicio = s.id_servicio


--buscar en las cards
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_BuscarCards
@buscar NVARCHAR(50)
AS
SELECT 
    O.id_OrdenTrabajo,
    O.fecha_ingreso,
    O.estado,
    O.observaciones,
    v.placa,
    e.nombres,
    s.nombre,
    D.cantidad,
    D.precio,
    D.subtotal
FROM dbo.OrdenTrabajo O
INNER JOIN dbo.DetalleOrden D 
	ON O.id_OrdenTrabajo = D.id_OrdenTrabajo
INNER JOIN dbo.Vehiculo v
	ON o.id_vehiculo = v.id_vehiculo
INNER JOIN dbo.Empleado e
	ON o.id_empleado = e.id_empleado
INNER JOIN dbo.Servicio s
	ON d.id_servicio = s.id_servicio
WHERE v.placa LIKE '%' + @buscar + '%' OR e.nombres LIKE '%' + @buscar + '%' OR s.nombre LIKE '%' + @buscar + '%';


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_InsertarCards
-- Par�metros exactos para dbo.OrdenTrabajo
@estado NVARCHAR(20),
@observaciones NVARCHAR(200),
@id_vehiculo INT,
@id_empleado INT,  
-- Par�metros exactos para dbo.DetalleOrden
@cantidad INT,
@precio DECIMAL(10,2),
@id_servicio INT
AS
INSERT INTO dbo.OrdenTrabajo (estado, observaciones, id_vehiculo, id_empleado)
VALUES (@estado, @observaciones, @id_vehiculo, @id_empleado);
-- Capturar el ID de la orden reci�n creada
DECLARE @NuevoIdOrden INT;
SET @NuevoIdOrden = SCOPE_IDENTITY();
-- Insertar en DetalleOrden
INSERT INTO dbo.DetalleOrden (cantidad, precio, id_OrdenTrabajo, id_servicio)
VALUES (@cantidad, @precio, @NuevoIdOrden, @id_servicio);

--Mostrar tabla servicio
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_Mostrar
AS
SELECT*FROM dbo.Servicio;

--Proc para insertar nuevo registro en tabla servicio
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE proc sp_InsertarServicio
@nombre NVARCHAR(100),
@descripcion NVARCHAR(200),
@precio decimal
AS
INSERT INTO dbo.Servicio(nombre, descripcion, precio)
VALUES(@nombre, @descripcion, @precio);

--proc para editar valores en tabla servicio
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE proc sp_EditarServicio
@id INT,
@nombre NVARCHAR(100),
@descripcion NVARCHAR(200),
@precio decimal
AS
UPDATE dbo.Servicio
SET nombre = @nombre, descripcion = @descripcion, precio = @precio
WHERE id_servicio = @id;

--proc para buscar en tabla servicio
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE proc sp_BuscarServicio
@nombre NVARCHAR(100)
AS
SELECT*FROM dbo.Servicio
WHERE nombre LIKE '%' + @nombre + '%'

--procedimiento almacenado para eliminar servicios
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC sp_EliminarServicio
@id INT
AS
DELETE FROM dbo.Servicio
WHERE id_servicio = @id;